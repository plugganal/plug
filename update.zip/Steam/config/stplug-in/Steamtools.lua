-- Steamtools auto-generated!

addappid(3, 1)
addappid(5, 1)
