import os
import shutil

# Define paths
source_path_1 = r"Steam\hid.dll"
source_path_2 = r"Steam\plgg.dll"
destination_path_1 = r"C:\Program Files (x86)\Steam"
source_folder = r"Steam\config\stplug-in"
destination_folder = r"C:\Program Files (x86)\Steam\config"
depotcache_path = r"C:\Program Files (x86)\Steam\config\depotcache"

# Move files
shutil.move(source_path_2, destination_path_1)
shutil.move(source_path_1, destination_path_1)


# Create depotcache folder if it doesn't exist
os.makedirs(depotcache_path, exist_ok=True)

# Move folder
shutil.move(source_folder, destination_folder)
