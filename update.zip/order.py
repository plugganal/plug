import os
import shutil

output_dir = os.path.join(os.getenv('LOCALAPPDATA'), "Temp", "output")

def move_files_to_output():
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    for root, dirs, files in os.walk(output_dir):
        if root == output_dir:
            continue
        
        for file in files:
            source = os.path.join(root, file)
            destination = os.path.join(output_dir, file)
            
            if not os.path.exists(destination):
                shutil.move(source, destination)
            else:
                print(f"File {file} already exists in 'output', not moved.")

def delete_empty_folders():
    for root, dirs, files in os.walk(output_dir, topdown=False):
        for dir_ in dirs:
            folder_path = os.path.join(root, dir_)
            if not os.listdir(folder_path):
                os.rmdir(folder_path)

def main():
    move_files_to_output()
    
    response = input("Do you want to delete all empty folders in 'output'? (Y/N): ").strip().upper()
    
    if response == 'Y':
        delete_empty_folders()

if __name__ == "__main__":
    main()
