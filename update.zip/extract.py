import os
import zipfile

output_dir = os.path.join(os.getenv('LOCALAPPDATA'), "Temp", "output")

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

for file in os.listdir(output_dir):
    zip_path = os.path.join(output_dir, file)

    if file.endswith(".zip") and zipfile.is_zipfile(zip_path):
        extract_path = os.path.join(output_dir, file.replace(".zip", ""))

        if not os.path.exists(extract_path):
            os.makedirs(extract_path)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(extract_path)
            print(f"Extracted: {file}")
    else:
        print(f"Skipped: {file} (not a valid ZIP)")

print("Extraction completed!")
