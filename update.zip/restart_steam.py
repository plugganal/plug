import subprocess

steam_exe = r"C:\Program Files (x86)\Steam\steam.exe"

def close_steam():
    try:
        subprocess.run("taskkill /f /im steam.exe", shell=True, check=True)
    except subprocess.CalledProcessError:
        pass

def start_steam():
    try:
        subprocess.Popen([steam_exe])
    except subprocess.CalledProcessError as e:
        pass

def restart_steam():
    close_steam()
    start_steam()

if __name__ == "__main__":
    restart_steam()
