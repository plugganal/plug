import os
import shutil
import subprocess

manifest_dest = r"C:\Program Files (x86)\Steam\config\depotcache"
stplug_in_dest = r"C:\Program Files (x86)\Steam\config\stplug-in"
luapacka_exe = r"C:\Program Files (x86)\Steam\config\stplug-in\luapacka.exe"
config_dir = r"C:\Program Files (x86)\Steam\config"
log_dir = os.path.join(os.getenv('LOCALAPPDATA'), "Temp", "output")

def copy_manifest():
    for file in os.listdir(config_dir):
        if file.endswith(".manifest"):
            shutil.copy2(os.path.join(config_dir, file), os.path.join(manifest_dest, file))
            print(f"File {file} copied to {manifest_dest}")

def move_st():
    for file in os.listdir(config_dir):
        if file.endswith(".st"):
            shutil.move(os.path.join(config_dir, file), os.path.join(stplug_in_dest, file))
            print(f"File {file} moved to {stplug_in_dest}")

def copy_lua():
    lua_files = []
    for file in os.listdir(config_dir):
        if file.endswith(".lua"):
            dest = os.path.join(stplug_in_dest, file)
            shutil.copy2(os.path.join(config_dir, file), dest)
            lua_files.append(dest)
            print(f"File {file} copied to {stplug_in_dest}")
    
    return lua_files

def run_luapacka(lua_files):
    if not os.path.exists(luapacka_exe):
        print(f"Error: {luapacka_exe} not found.")
        return
    
    try:
        subprocess.run([luapacka_exe] + lua_files, check=True)
        print("Successfully executed stplug-in/luapacka.exe.")
    except subprocess.CalledProcessError as e:
        print(f"Error running luapacka.exe: {e}")

def main():
    copy_manifest()
    move_st()
    lua_files = copy_lua()
    if lua_files:
        run_luapacka(lua_files)

if __name__ == "__main__":
    main()
