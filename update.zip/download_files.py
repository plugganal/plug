import os
import requests
from tqdm import tqdm
from concurrent.futures import ThreadPoolExecutor, as_completed

DOWNLOAD_URL = "https://cysaw.top/uploads/{}.zip"
STEAM_API_URL = "https://store.steampowered.com/api/appdetails?appids={}"

log_dir = os.path.join(os.getenv('LOCALAPPDATA'), "Temp", "logs")
os.makedirs(log_dir, exist_ok=True)

SAVE_FOLDER = os.path.join(os.getenv('LOCALAPPDATA'), "Temp", "output")
os.makedirs(SAVE_FOLDER, exist_ok=True)

url = "https://raw.githubusercontent.com/2backside/plgg/refs/heads/main/host"

# Fetch game IDs from the URL
response = requests.get(url)
game_ids = response.text.splitlines()

total_games = len(game_ids)
downloaded_games = 0

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
}

def download_game(game_id, index, total_games):
    game_name = "Unknown"
    progress_percent = (index / total_games) * 100
    file_path = os.path.join(SAVE_FOLDER, f"{game_id}.zip")
    
    try:
        response = requests.get(STEAM_API_URL.format(game_id), headers=HEADERS)
        game_data = response.json()
        if game_data.get(game_id, {}).get("success", False):
            game_name = game_data[game_id]["data"]["name"]
    except Exception as e:
        print(f"Error fetching game name {game_id}: {e}")

    if os.path.exists(file_path):
        print(f"File {game_id}.zip already exists. Skipping...")
        return True  

    file_url = DOWNLOAD_URL.format(game_id)
    
    try:
        response = requests.get(file_url, stream=True, headers=HEADERS)
        
        if response.status_code == 404:
            print(f"File {game_id}.zip ({game_name}) not found. [{index}/{total_games} {progress_percent:.2f}%]")
            return False

        total_size = int(response.headers.get('content-length', 0))

        with open(file_path, "wb") as file, tqdm(
            desc=f"Downloading {game_name} ({game_id}) [{index}/{total_games} {progress_percent:.2f}%]",
            total=total_size,
            unit="B",
            unit_scale=True,
            unit_divisor=1024,
        ) as bar:
            for data in response.iter_content(chunk_size=4096):
                file.write(data)
                bar.update(len(data))

        print(f"Completed: {index}/{total_games} {progress_percent:.2f}%.")
        return True
    except Exception as e:
        print(f"Error downloading {game_id}.zip ({game_name}): {e}")
        return False

with ThreadPoolExecutor(max_workers=8) as executor:
    futures = [executor.submit(download_game, game_id, index, total_games) for index, game_id in enumerate(game_ids, start=1)]
    
    for future in as_completed(futures):
        if future.result():
            downloaded_games += 1

print("\nDownload complete!")
